module.exports = {
    dbHost: 'bulkdataprocessdb.ctzzdvu4ji7r.us-east-1.rds.amazonaws.com',
    username: 'BulkDataUser',
    password: 'BulkDataUser',
    database: 'BulkDataDB',
    BUCKET_NAME: 'bulk-document-bucket',
    IAM_USER_KEY: 'AKIASEHJUOM3HAK6PB6P',
    IAM_USER_SECRET: '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'
}
