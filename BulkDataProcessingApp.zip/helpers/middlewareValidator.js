const validator = require('../helpers/validator');

const registorValidator = (req, res, next) => {
    const validationRule = {
        "email": "required|email",
        "password": "required|string|min:6"
    }
    validator(req.body, validationRule, {}, (err, status) => {
        if (!status) {
            res.status(412)
                .send({
                    success: false,
                    message: 'Validation failed',
                    data: err
                });
        } else {
            next();
        }
    });
}

const userValidator = (req, res, next) => {
    const validationRule = {
        "email": "required|email",
        "token": "required|integer"
    }
    validator(req.body, validationRule, {}, (err, status) => {
        if (!status) {
            res.status(412)
                .send({
                    success: false,
                    message: 'Validation failed',
                    data: err
                });
        } else {
            next();
        }
    });
}

const cartValidator = (req, res, next) => {
    const validationRule = {
        "userId": "required|integer",
        "fileName":"required|string",
        "quantity": "required|integer"
    }
    
    validator(req.body, validationRule, {}, (err, status) => {
        if (!status) {
            res.status(412)
                .send({
                    success: false,
                    message: 'Validation failed',
                    data: err
                });
        } else {
            next();
        }
    });
}

module.exports = { 
    registorValidator : registorValidator,
    userValidator : userValidator,
    cartValidator : cartValidator
}