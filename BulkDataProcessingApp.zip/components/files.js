const JsonResponse = require("../utils/jsonResponse");
const config = require("../config/config");
const fs = require("fs");
const xlsx = require('node-xlsx');

var AWS = require("aws-sdk");

const s3bucket = new AWS.S3({
  accessKeyId: config.IAM_USER_KEY,
  secretAccessKey: config.IAM_USER_SECRET,
  Bucket: config.BUCKET_NAME,
});

/* Upload file */
const uploadFile = function (req, callback) {
  try {
    const file = req.file;
    var ResponseData = [];
    var buffer = Buffer.from(file.buffer);

      var params = {
        Bucket: config.BUCKET_NAME,
        Key: file.originalname,
        Body: buffer,
        ACL: "public-read",
      };

      s3bucket.upload(params, function (error, response) {
        if (error) {
          console.log("Error message", error);
          callback(JsonResponse(500, "FAILED", JSON.stringify(error), null));
        } else {
          console.log("Inside single file upload");
          ResponseData.push(response);
          if (ResponseData.length == 1) {
            callback(null, JsonResponse(200,"SUCCESS","Successfullly Uploaded The File", ''));
          }
        }
      });
    
  } catch (ex) {
    console.log("exception", ex);
    callback(JsonResponse(500), "FAILED", JSON.stringify(ex), null);
  }
};

/* Upload Multiple file */
const uploadMutlipleFile = function (req, callback) {
  try {
    for (let i = 0; i < req.files.length; i++) {
      const file = req.files[i];
      var ResponseData = [];
      var buffer = Buffer.from(file.buffer);

      var params = {
        Bucket: config.BUCKET_NAME,
        Key: file.originalname,
        Body: buffer,
        ACL: "public-read",
      };

      s3bucket.upload(params, function (error, response) {
        if (error) {
          console.log("Error message", error);
          callback(JsonResponse(500, "FAILED", JSON.stringify(error), null));
        } else {
          console.log("Inside Multiple file upload");
          ResponseData.push(response);
          if (ResponseData.length == 1) {
            callback(null,JsonResponse(200,"SUCCESS","Successfullly Uploaded All The Files", ''));
          }
        }
      });
    }
  } catch (ex) {
    console.log("exception", ex);
    callback(JsonResponse(500), "FAILED", JSON.stringify(ex), null);
  }
};

/* Get Given file and Download it */
const getFile = function (req, callback) {
  const fileName = req.file;
  const fileExtension = fileName.split('.')[1];
  const filePath = "./tmp/";
  var file;
  var result;

  const bucketParams = {
    Bucket: config.BUCKET_NAME,
    Key: fileName,
  };

  try {
    if(fileExtension == 'json'){
        s3bucket.getObject(bucketParams, function (error, response) {
          if (error) {
            console.log("Error message", error);
            callback(JsonResponse(500, "FAILED", JSON.stringify(error), null));
          } else {
            console.log("Inside GET file");
            fs.writeFileSync(filePath, response.Body.toString());
            callback(null,JsonResponse(200,"SUCCESS","Successfullly Downloaded The File",''));
          }
        });
    }else if(fileExtension == 'xlsx'){
        console.log("Inside GET file");
        file = s3bucket.getObject(bucketParams).createReadStream();
        result = fs.createWriteStream(filePath+fileName)
        file.pipe(result);
      return callback(null,JsonResponse(200,"SUCCESS","Successfullly Downloaded The File",''));
    }
  } catch (ex) {
    console.log("exception", ex);
    callback(JsonResponse(500), "FAILED", JSON.stringify(ex), null);
  }
};

const getFileByParams = function (req, callback) {
  const fileType = req.type;
  const amount = req.amount;
  const tax = req.tax;
  const subType = req.subType;
  const fileName = req.file;

  let uri;
  if(req.rui != null){
   uri = req.uri;
  }else{
   uri ='https://bulk-document-bucket.s3.amazonaws.com/' + fileName;
  }

 const fileExtension = fileName.split('.')[1];
 const filePath = "./tmp/";
 const bucketParams = {
   Bucket: config.BUCKET_NAME,
   Key: fileName,
 };

 try {

  if(fileExtension == 'json'){
   s3bucket.getObject(bucketParams, function (error, response) {
     if (error) {
       console.log("Error message", error);
       callback(JsonResponse(500, "FAILED", JSON.stringify(error), null));
     } else {
       console.log("Inside GET file by params");
       let responseString = response.Body.toString()
       let jsonContent = JSON.parse(responseString)
       if(fileType == jsonContent['fileType'] && amount == jsonContent['price'] && tax == jsonContent['tax'] && subType == jsonContent['subType'] ){ 
        fs.writeFileSync(filePath, response.Body.toString());
        callback(null,JsonResponse(200,"SUCCESS","Successfullly Downloaded The File with given params",''));
       }else{
        callback(null, JsonResponse(404, 'FAILED', 'No File Found For the given params', ''));
       }
     }
   });
  }else if(fileExtension == 'xlsx'){
    let excelFile = s3bucket.getObject(bucketParams).createReadStream();
    let buffers = [];
    let result;
    let file;
    excelFile.on('data', function (data) {
      buffers.push(data);
    });

    excelFile.on('end', function () {
    var buffer = Buffer.concat(buffers);
    var workbook = xlsx.parse(buffer);
    
    let fileDetails = {};
    
    fileDetails.fileName = fileName;
    
    if(workbook[0].data[0][1] == 'FileType'){
      fileDetails.fileType = workbook[0].data[1][1]
    }

    if(workbook[0].data[0][2] == 'Price'){
      fileDetails.filePrice = workbook[0].data[1][2]
    }
    
    if(workbook[0].data[0][4] == 'Tax'){
      fileDetails.tax = workbook[0].data[1][4]
    }

    if(workbook[0].data[0][4] == 'SubType'){
      fileDetails.subType = workbook[0].data[1][5]
    }

    if(fileType == fileDetails.filePrice && amount == fileDetails.filePrice && tax == fileDetails.fileDetails && subType == fileDetails.subType ){ 
      result = fs.createWriteStream(filePath+fileName)
      file.pipe(result);
      return callback(null,JsonResponse(200,"SUCCESS","Successfullly Downloaded The File with given params",''));
    }else{
      callback(null, JsonResponse(404, 'SUCCESS', 'No File Found For the given params', ''));
     }
  });
  }
 } catch (ex) {
   console.log("exception", ex);
   callback(JsonResponse(500), "FAILED", JSON.stringify(ex), null);
 }
};

/* List All the Files */
const listAllFiles = async function (req, callback) {
  try {
    var result = { files: [] }
    let isTruncated = true;
    let marker;
    while(isTruncated) {
      let params = { Bucket: config.BUCKET_NAME };
      if (marker) params.Marker = marker;
        const response = await s3bucket.listObjects(params).promise();
        response.Contents.forEach(file => {
          result.files = result.files.concat(file.Key);
        });
        isTruncated = response.IsTruncated;
        if (isTruncated) {
          marker = response.Contents.slice(-1)[0].Key;
        }
    }
    callback(null,JsonResponse(200,"SUCCESS","Successfullly Fetched All The File", result));
  } catch (ex) {
    console.log("exception", ex);
    callback(JsonResponse(500), "FAILED", JSON.stringify(ex), null);
  }
};

/* GET File Details */
const getFileDetials = function(req, callback){
  
  const fileName = req.file;
  var fileExtension = fileName.split('.')[1];
  
  const bucketParams = {
    Bucket: config.BUCKET_NAME,
    Key: fileName
  };

  try {
    if(fileExtension == 'json'){
    var file = s3bucket.getObject(bucketParams, function (error, response) {
      if (error) {
        console.log("Error message", error);
        callback(JsonResponse(500, "FAILED", JSON.stringify(error), null));
      } else {
          console.log("Inside GET file");
            let responseString = response.Body.toString()
            let jsonContent = JSON.parse(responseString)
            let fileDetails = {};
              fileDetails.fileName = fileName;
              fileDetails.fileType = jsonContent['fileType']
              fileDetails.fileDescription = jsonContent['description']
              fileDetails.filePrice = jsonContent['price']
            callback(null,JsonResponse(200,"SUCCESS","Successfullly Fetched The Given File Details", fileDetails));
          }
        })
      }else if(fileExtension == "xlsx"){
        let excelFile = s3bucket.getObject(bucketParams).createReadStream();
        let buffers = [];
        excelFile.on('data', function (data) {
          buffers.push(data);
        });

        excelFile.on('end', function () {
        var buffer = Buffer.concat(buffers);
        var workbook = xlsx.parse(buffer);
        
        let fileDetails = {};
        
        fileDetails.fileName = fileName;
        
        if(workbook[0].data[0][1] == 'Type'){
          fileDetails.fileType = workbook[0].data[1][1]
        }
        
        if(workbook[0].data[0][2] == 'Price'){
          fileDetails.filePrice = workbook[0].data[1][2]
        }
        
        if(workbook[0].data[0][3] == 'Description'){
          fileDetails.fileDescription = workbook[0].data[1][3]
        }
        callback(null,JsonResponse(200,"SUCCESS","Successfullly Fetched The Given File Details", fileDetails));
      });
      }
    
  } catch (ex) {
    console.log("exception", ex);
    callback(JsonResponse(500), "FAILED", JSON.stringify(ex), null);
  }
};

module.exports = {
  uploadFile: uploadFile,
  uploadMutlipleFile: uploadMutlipleFile,
  getFile: getFile,
  getFileByParams: getFileByParams,
  listAllFiles: listAllFiles,
  getFileDetials: getFileDetials
};
