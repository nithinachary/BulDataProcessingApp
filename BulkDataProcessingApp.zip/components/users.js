'use strict';

var crypto = require('crypto');
var nodemailer = require('nodemailer');
var moment = require('moment');
const db = require('../db/db');
const config = require('../config/config');
const JsonResponse = require("../utils/jsonResponse");

var smtpTransport = nodemailer.createTransport({
    service: "Gmail",
    auth: {
        user: "",
        pass: ""
    }
});

/* GET All Logged In User */
const getUser = function (req, callback) {
    try {
        let email = req.email;
        let password = req.password;
        let emailQuery = 'SELECT * FROM `BulkDataDB`.`user` where email = ' + "'"+ email + "'";
        db.query(emailQuery, null, function (error, response) {
            if (error) {
                console.log('Error message', error);
                callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null));
            } else {
                console.log('Inside Get Logged In User Query');
                if(response.length == 0){
                    callback(null, JsonResponse(404, 'FAILURE', 'No Such User Found. The email address ' + email + ' is not associated with any account. Double-check your email address and try again.', response));
                }else if(response.length > 0){
                    let passwordQuery = 'SELECT * FROM `BulkDataDB`.`user` where email = ' + "'"+ email + "' and password = '" + password + "'" ;
                    db.query(passwordQuery, null, function (error, response) {
                        if (error) {
                            console.log('Error message', error);
                            callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null));
                        }else{
                            if(response.length == 0){
                                callback(null, JsonResponse(401, 'FAILED', 'Invalid Email Or Password', ''));
                            }else if(response.length>0){
                                if(response[0].isVerified == 1){
                                    callback(null, JsonResponse(200, 'SUCCESS', 'Successfullly Logged In', ''));
                                }else{
                                    callback(null, JsonResponse(401, 'SUCCESS', 'Your account has not been verified', '')); 
                                }
                            }
                        }
                    })
                }
            }
        });
    } catch (ex) {
        console.log('exception', ex);
        callback(JsonResponse(500, 'FAILED', JSON.stringify(ex), null));
    }
};

/* Register New  User */
const registerUser = function (req, callback) {
    try {
        let email = req.body.email;
        let password = req.body.password;
        let searchQuery = 'SELECT * FROM `BulkDataDB`.`user` where email = ' + "'"+ email + "'";
        db.query(searchQuery, null, function (error, response) {
                if (error) {
                    console.log('Error message', error);
                    callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null))
                } else {
                    if(response.length > 0){
                        callback(null, JsonResponse(401, 'SUCCESS', 'The email address you have entered is already registered', ''));
                    }else{
                        console.log('Inside Register Query');
                        let token = crypto.randomBytes(16).toString('hex');
                        let addQuery = 'INSERT INTO `BulkDataDB`.`user` (email, password, createdOn, token, tokenCreatedTime, tokenExpirationTime) VALUES (' + "'" + email + "','" + password  + "', NOW(), '" + token +"', CURRENT_TIME(), ADDTIME(current_time(),'00:30:00'))";
                        db.query(addQuery, null, function (error, response) {
                            if (error) {
                                console.log('Error message', error);
                                callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null))
                            } else{
                                var mailOptions = { 
                                    from: 'no-reply@yourwebapplication.com', 
                                    to: email, 
                                    subject: 'Account Verification Token', 
                                    text: 'Hello,\n\n' + 'Please verify your account by clicking the link: \nhttp:\/\/' + req.headers.host + '\/confirmation\/' + token + '.\n' 
                                };
                                   
                                smtpTransport.sendMail(mailOptions, function (error) {
                                if (error) { 
                                    console.log('Error message', error);
                                    callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null))
                                }
                                    callback(null, JsonResponse(200, 'SUCCESS', 'A verification email has been sent to ' + email, 'Registratoion Id: ' + response.insertId));
                                });
                            }
                    })
                    
                }
            }
        });
    } catch (ex) {
        console.log('exception', ex);
        callback(JsonResponse(500, 'FAILED', JSON.stringify(ex), null));
    }
};

/* Verify the Registered User */
const verfiyUser = function(req, callback){
    try {

        let token = req.body.token;
        let email = req.body.email;
        let searchQuery = 'SELECT * FROM `BulkDataDB`.`user` WHERE token = ' + "'"+ token + "' and email = '" + email + "'";
        db.query(searchQuery, null, function (error, response) {
            if (error) {
                console.log('Error message', error);
                callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null))
            } else {
                if(response.length > 0){
                    console.log(response[0].isVerified)
                    if(response[0].isVerified == '1'){
                        callback(null, JsonResponse(200, 'SUCCESS', 'This user has already been verified', ''));  
                    }else{
                        var currentTime = new Date().getTime();
                        var tokenExpirationTime = response[0].tokenExpirationTime.getTime();

                        let earliest = currentTime < tokenExpirationTime ? currentTime : tokenExpirationTime
                        let latest = tokenExpirationTime < currentTime ? currentTime : tokenExpirationTime
                        let hours = Math.abs(Math.round((earliest - latest)/360000))
                    
                        if(hours > 30){
                           callback(null, JsonResponse(401, 'SUCCESS', 'Token expired. Please check with Admin', '')); 
                        }else{
                            let updateQuery = 'UPDATE `BulkDataDB`.`user` SET `isVerified` = true  where email = ' + "'" + email + "'";
                            db.query(updateQuery, null, function (error, response) {
                                if (error) {
                                    console.log('Error message', error);
                                    callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null))
                                } else {
                                    callback(null, JsonResponse(200, 'SUCCESS', 'The account has been verified. Please log in', ''));
                                }
                            });
                        }   
                    }
                }else{
                    callback(null, JsonResponse(404, 'NOT FOUND', 'No such Token/User exists', '')); 
                }
            }
        });
    } catch (ex) {
        console.log('exception', ex);
        callback(JsonResponse(500, 'FAILED', JSON.stringify(ex), null));
    }
}

/* User Cart Detials */
const userCartDetails =  function(req, callback){

    try {
        var userId = req.userId;
        var quantity = req.quantity;
        var fileName = req.fileName;
        var product = {};
        var cart = {products:[]}
            if(quantity > 0){
                let searchQuery = 'SELECT * FROM `BulkDataDB`.`products` where fileName = ' + "'"+ fileName + "'";
                db.query(searchQuery, function (error, response) {
                    if (error) {
                        console.log('Error message', error);
                        callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null));
                    } else {
                        console.log('Inside Cart Details Query');
                        if(response.length == 0){
                            callback(null, JsonResponse(401, 'FAILURE', 'No Such File Found', response));
                        }else if(response.length > 0){
    
                            var productId = response[0].productId;
                            var price = response[0].price;
                            var subTotal = quantity * price;

                            product.productId = productId
                            product.price = price
                            product.fileName = fileName;
                            product.quantity = quantity;
                            product.subTotal = subTotal;

                            cart.products.push(product)
                            
                            var searchCart = 'Select * from `BulkDataDB`.`cart` where productId =' +  productId + " and userId = " + userId  ;
                            db.query(searchCart, null, function (error, response) {
                                if (error) {
                                    console.log('Error message', error);
                                    callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null))
                                } else {
                                    if(response.length == 0){
                                        console.log(response)
                                        var insertQuery = 'INSERT INTO `BulkDataDB`.`cart` (userId, productId, quantity, price, subtotal) VALUES (' + "'" + userId + "','" + productId  + "','" +  quantity + "','" + price + "','"+ subTotal + "')";
                                        db.query(insertQuery, null, function (error, response) {
                                            if (error) {
                                                console.log('Error message', error);
                                                callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null))
                                            } else {
                                                callback(null, JsonResponse(200, 'SUCCESS', 'Item added to the cart', cart ));
                                            }
                                        });
                                    }else{
                                        callback(null, JsonResponse(403, 'FAILED', 'Item already added to cart', '')); 
                                    }
                                }
                            });
                        }
                    }
                });
                
            }else{
                callback(null, JsonResponse(401, 'FAILURE', 'Quantiy should be greater than 0', ''));
            }
        } catch (ex) {
            console.log("exception", ex);
            callback(JsonResponse(500), "FAILED", JSON.stringify(ex), null);
    }
    
  };

  /* User Final Payment Detials */
  const getFinalPaymentDetails = function (req, callback) {
    try {
        let userId = req.userId;
        let userCartquery = 'SELECT * FROM `BulkDataDB`.`cart` where userId = ' + userId;
        db.query(userCartquery, null, function (error, response) {
            if (error) {
                console.log('Error message', error);
                callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null));
            } else {
                console.log('Inside Get Query');
                if(response.length == 0){
                    callback(null, JsonResponse(404, 'FAILURE', 'No User Found'));
                }else if(response.length > 0){
                    let productQuery = 'SELECT cart.quantity, cart.subtotal, cart.price as cartPrice, products.price as productPrice FROM BulkDataDB.cart left join BulkDataDB.products on cart.productId = products.productId where BulkDataDB.cart.userId =' + userId;
                    db.query(productQuery, null, function (error, response) {
                        if (error) {
                            console.log('Error message', error);
                            callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null));
                        }else{
                            if(response.length == 0){
                                callback(null, JsonResponse(404, 'FAILED', 'No Valid Cart for the given User', ''));
                            }else if(response.length>0){
                                var totalAmount = [];
                                var finalPayingAmount =0;
                                for(let i=0; i < response.length; i++){
                                    var cartPrice = response[i].cartPrice
                                    var productPrice = response[i].productPrice
                                    var quantity = response[i].quantity
                                    var subTotal = response[i].subtotal
                                    var newSubTotal = 0;
                                    if(cartPrice != productPrice){
                                          newSubTotal = quantity * productPrice
                                          totalAmount.push(newSubTotal)
                                    }else{
                                        totalAmount.push(subTotal)
                                    }
                                }
                                for(var i = 0; i < totalAmount.length; i++){
                                    finalPayingAmount += totalAmount[i]
                                }
                            }
                            callback(null, JsonResponse(200, 'SUCCESS', 'Successfully Verified Final Paying Amount', 'Final Payable Amount = ' + finalPayingAmount));
                        }
                    })
                }
            }
        });
    } catch (ex) {
        console.log('exception', ex);
        callback(JsonResponse(500, 'FAILED', JSON.stringify(ex), null));
    }
};

module.exports ={
    getUser: getUser,
    registerUser: registerUser,
    verfiyUser: verfiyUser ,
    userCartDetails: userCartDetails,
    getFinalPaymentDetails: getFinalPaymentDetails
}