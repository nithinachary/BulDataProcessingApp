module.exports = (statusCode, status, msg, data) => {
    var responseObj = {};
    responseObj.code = statusCode;
    responseObj.status = status;
    responseObj.msg = msg || {
        "msg": "no data available"
    };
    responseObj.data = data || "";
    return responseObj;
}