var express = require('express');
var router = express.Router();
var userComponent = require('../components/users')
const validation = require('../helpers/middlewareValidator');

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

/* GET All Registered Link */
router.get('/login', function (req, res, next) {
  console.log('Inside GET: /login route');

  userComponent.getUser(req.body, validation.registorValidator, function (err, response) {
    if (err) {  
      res.status(err.code, {
        'Content-Type': 'application/json; charset=utf-8'
      });
      res.end(err.message);
    } else {
      res.status(response.code, {
        'Content-Type': 'application/json; charset=utf-8'
      });
      res.end(JSON.stringify(response));
    }
  });
});

router.post("/registerUser", validation.registorValidator, function (req, res) {
  userComponent.registerUser(req, function(err, response){
    if (err) {
      res.end(err);
    } else {
      res.status(response.code, {
        'Content-Type': 'application/json; charset=utf-8'
      });
      res.end(JSON.stringify(response));
    }
  });         
});

router.get("/verifyUser", validation.userValidator , function (req, res) {
  userComponent.verfiyUser(req, function(err, response){
    if (err) {
      res.end(err);
    } else {
      res.status(response.code, {
        'Content-Type': 'application/json; charset=utf-8'
      });
      res.end(JSON.stringify(response));
    }
  });         
});

router.post("/userCart", validation.cartValidator, function (req, res) {
  userComponent.userCartDetails(req.body, function(err, response){
    if (err) {
      res.end(err);
    } else {
      res.status(response.code, {
        'Content-Type': 'application/json; charset=utf-8'
      });
      res.end(JSON.stringify(response));
    }
  });         
});

router.get("/getFinalPaymentDetails", function (req, res) {
  userComponent.getFinalPaymentDetails(req.query, function(err, response){
    if (err) {
      res.end(err);
    } else {
      res.status(response.code, {
        'Content-Type': 'application/json; charset=utf-8'
      });
      res.end(JSON.stringify(response));
    }
  });         
});

module.exports = router;
