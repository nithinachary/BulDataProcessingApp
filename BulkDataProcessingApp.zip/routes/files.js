var express = require("express");
var multer = require("multer");
var router = express.Router();
var fileBulkComponent = require('../components/files')

var storage = multer.memoryStorage({
  destination: function (req, file, callback) {
    callback(null, "");
  },
});

var multipleUpload = multer(
  { storage: storage },
  {fileFilter : function (req, file, cb) {
    if (!file.originalname.match(/\.(xlsx|json|xls)$/)) {
        return cb(new Error('Only JSON & EXCEL files are allowed!'));
    }
    cb(null, true);
  } }
  ).array("file");

var upload = multer(
   {storage: storage }, 
   {fileFilter : function (req, file, cb) {
    if (!file.originalname.match(/\.(xlsx|json|xls)$/)) {
        return cb(new Error('Only JSON & EXCEL files are allowed!'));
    }
    cb(null, true);
  } }
  ).single("file");

router.post("/uploadFile", upload, function (req, res) {
  fileBulkComponent.uploadFile(req, function(err, response){
    if (err) {
      res.end(err);
    } else {
      res.status(response.code, {
        'Content-Type': 'application/json; charset=utf-8'
      });
      res.end(JSON.stringify(response));
    }
  });
           
});

router.post("/uploadMultipleFile", multipleUpload, function (req, res) {

  fileBulkComponent.uploadMutlipleFile(req, function(err, response){
    if (err) {
      res.end(err);
    } else {
      res.status(response.code, {
        'Content-Type': 'application/json; charset=utf-8'
      });
      res.end(JSON.stringify(response));
    }
  });
           
});

router.get("/getFile", function (req, res) {

  fileBulkComponent.getFile(req.query, function(err, response){
    if (err) {
      res.end(err);
    } else {
      res.status(response.code, {
        'Content-Type': 'application/json; charset=utf-8'
      });
      res.end(JSON.stringify(response));
    }
  });
           
});

router.get("/getFileByParams", function (req, res) {

  fileBulkComponent.getFileByParams(req.query, function(err, response){
    if (err) {
      res.end(err);
    } else {
      res.status(response.code, {
        'Content-Type': 'application/json; charset=utf-8'
      });
      res.end(JSON.stringify(response));
    }
  });           
});

router.get("/listAllFiles", function (req, res) {

  fileBulkComponent.listAllFiles(req, function(err, response){
    if (err) {
      res.end(err);
    } else {
      res.status(response.code, {
        'Content-Type': 'application/json; charset=utf-8'
      });
      res.end(JSON.stringify(response));
    }
  });         
});

router.get("/getFileDetails", function (req, res) {
  fileBulkComponent.getFileDetials(req.query, function(err, response){
    if (err) {
      res.end(err);
    } else {
      res.status(response.code, {
        'Content-Type': 'application/json; charset=utf-8'
      });
      res.end(JSON.stringify(response));
    }
  });         
});


module.exports = router;
