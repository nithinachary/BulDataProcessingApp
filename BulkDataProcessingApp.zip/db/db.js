const mysql = require('mysql');
const config = require('../config/config');

var pool = mysql.createPool(
        {
                host: config.dbHost,
                user: config.username,
                password: config.password,
                database: config.database,
                multipleStatements: true
        }
);

var DB = (function () {

        function _query(query, params, callback) {
                pool.getConnection(function (err, connection) {
                        if (err) {
                                console.log(err);
                                callback(err, null);
                                throw err;
                        }

                        connection.query(query, params, function (err, rows) {
                                connection.release();
                                if (!err) {
                                        callback(null, rows);
                                } else {
                                        callback(err, null);
                                }
                        });

                        connection.on('error', function (err) {
                                connection.release();
                                callback(err, null);
                                throw err;
                        });
                });
        }

        return {
                query: _query
        };
})();

module.exports = DB;